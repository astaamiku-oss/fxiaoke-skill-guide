# 页面筛选与ego lite控制

首次安装从 [ego lite官网](https://lite.ego.app/) 下载对应系统版本，用户本人完成引导并登录纷享销客。不要替用户输入密码、跳过系统权限或处理验证码。首次引导后CLI不可用时，先让用户重启AI软件以刷新PATH；仍失败再诊断实际入口。

页面操作只能通过ego lite。已有ego-browser技能则读其说明；本参考提供所需的最小流程。Mac可用带引号的heredoc，Windows PowerShell可用单引号here-string管给`ego-browser nodejs`；Python封装使用进程stdin，两者都不执行网页返回的脚本。

Mac示例：
```bash
ego-browser nodejs <<'EOF'
const spaces = await listTaskSpaces();
const existing = spaces.find(x => x.name === 'fxiaoke team leads');
if (existing && existing.ownership !== 'agent') throw new Error('任务空间需要本人确认恢复，已停止');
const task = await useOrCreateTaskSpace('fxiaoke team leads');
await openOrReuseTab('https://www.fxiaoke.com/XV/UI/Home', {wait:true, timeout:25});
cliLog(await snapshotText());
EOF
```

Windows PowerShell同一代码体的传入形式：
```powershell
@'
const spaces = await listTaskSpaces();
const existing = spaces.find(x => x.name === 'fxiaoke team leads');
if (existing && existing.ownership !== 'agent') throw new Error('任务空间需要本人确认恢复，已停止');
const task = await useOrCreateTaskSpace('fxiaoke team leads');
await openOrReuseTab('https://www.fxiaoke.com/XV/UI/Home', {wait:true, timeout:25});
cliLog(await snapshotText());
'@ | ego-browser nodejs
```

每轮先接回同一空间；`snapshotText()`返回当前可见语义树与`@N`引用。`click('@N')`点击，`fillInput('@N','文本')`输入。引用只能取自最新快照；页面变化后重读。坐标操作前先`captureScreenshot()`。`js()`只做需要的读取、核实和已验证接口，不猜写接口。返回用`cliLog`；等待秒数参数为秒。

## 把中文条件映射到实际页面

1. 进入线索池，确认库为公共库且租户正确。读取本页当前生效条件，按用户条件与个人偏好重新设置；旧查询遗留值不能偷偷参与本轮。
2. 依据最新页面点击筛选。可见字段包括姓名、手机、微信号、客户公司名称、线索来源、官网表单类型、市场活动名称、线索日期、线索阶段/流向、负责人。额外字段需现场检查“筛选”菜单，不能只凭截图假设存在。
3. 明确“且/或”关系。例如“官网来源，商务咨询或伙伴咨询”表示来源与表单条件之间为且，两种表单之间为或。原生控件不支持时可分组只读查询后按记录ID取并集/交集，并向用户说明；分页不完整时不能声称查询完整。
4. 读取各字段实际的包含/等于/属于/早于等运算符，选择真实标签，不推断枚举码。只有一次查询需要的姓名、手机等敏感值不落入配置或输出文件。
5. 点“筛选”，等待列表加载完，再核对生效条件、结果和必要分页。灰色、受限或未找到的字段如实说明。不能用不带这些条件的CLI查询替代后声称成功。
6. 提取原记录的24位ID及详情链接。后续查重用这些ID，领取仍需明确授权。

## 登录与用户接管

`pageInfo()`标题是CRM登录系统，或出现验证码时，`handOffTaskSpace(task.id)`交回，核实返回`done`后告知本人操作。用户主动接管、inactive或unassigned均硬停止整项浏览器任务；不能改名新建空间绕过。

仅在本人明确确认继续后，用`listTaskSpaces()`找原空间；已知交回可`takeOverTaskSpace(id)`恢复，inactive/unassigned用`claimTaskSpace(id)`，再`listTabs()`及`switchTab(targetId)`选原页。不要每轮自动调用接管。

任务完成且上一轮已确认结果后，单独一轮调用`completeTaskSpace(id,{keep:false})`，先检查ownership仍为agent，并检查返回done。只在本人要求保留或该页需要手动处理时保留。登录/接管暂停时不得自动关闭。
