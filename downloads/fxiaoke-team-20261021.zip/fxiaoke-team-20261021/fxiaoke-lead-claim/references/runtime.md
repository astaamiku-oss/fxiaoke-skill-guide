# 运行与个人配置

以下命令由AI执行，普通同事无需记忆。`<python>`替换为实际可用的Python 3.10+解释器，`<skill>`替换为本技能绝对目录；通过结构化进程参数或符合当前shell的引号传参，尤其是路径带空格时。

```text
<python> <skill>/scripts/fx config show
<python> <skill>/scripts/fx config init
<python> <skill>/scripts/fx status
<python> <skill>/scripts/fx --json shortlist --scan 400 --top 5 --check-owners
<python> <skill>/scripts/fx --json shortlist --before 2026-06-01 --position 架构师 --recent-points nonzero --check-owners
<python> <skill>/scripts/fx detail <内部记录ID>
<python> <skill>/scripts/fx duplicates <内部记录ID>
<python> <skill>/scripts/fx claim <已明确授权的内部记录ID> --execute
<python> <skill>/scripts/fx call-failed <OB ID>
<python> <skill>/scripts/fx call-failed <OB ID> --execute --text "用户确认的记录原文"
```

全局参数`--config`、`--json`、`--keep-open`、`--output`放在子命令之前。连续查询可`--keep-open`；完成后运行`close`。只在已完成、仍由agent控制时关闭空间。遇待确认状态不自动清理或抢回。

## 配置位置和优先级

Mac：当前用户 `~/.config/fxiaoke-lead-claim/preferences.json`。
Windows：当前用户 `%LOCALAPPDATA%/fxiaoke-lead-claim/preferences.json`。
缺省文件不存在则使用团队默认；`config init`新建，已有文件拒绝覆盖。明确指定但不存在/无效的`--config`报错，不静默使用默认。`config show/init`均不连接浏览器。

优先级：本次用户条件 > 本人已保存偏好 > 团队默认。不把一位同事的配置写入包内或其他同事的配置。临时覆盖多字段时可用经校验的临时JSON并通过`--config`指定；不改变默认状态文件，也不把姓名、手机、微信号等查询值写入长期配置。

| 配置键 | 团队默认 | 用途 |
|---|---|---|
| version | 1 | 配置结构版本 |
| lead_date_before | null | 不限日期；设置YYYY-MM-DD后按东八区“早于” |
| positions | [] | 不限职位；填写页面职位大类原文 |
| require_company | false | 是否排除空公司 |
| prefer_nonzero_recent_points | false | 是否强制近三个月积分>0，空值不补足 |
| company_include_keywords | [] | 公司名包含任一关键词 |
| company_exclude_keywords | [] | 公司名含任一关键词则排除 |
| partner_mode | false | 可选伙伴名称初筛及技术咨询评分，并不证明伙伴身份 |
| exclude_historical_no_interest | false | 是否按明确的历史无意向字段排除 |
| deduplicate_company | true | shortlist同公司只留一条；空公司按各自记录保留 |
| watched_sales_lead_owners | [] | 需特别评估的重复销售线索负责人，必须由团队或本人提供 |

公司关键词、伙伴模式、积分与历史反馈门槛在扫描后做本地筛选；`scanned`是读到的条数，不是匹配条数。`search`不做公司去重，`shortlist`按配置去重。选择`--top`后详情刷新和查重可能进一步减少数量，不声称穷尽公共库。扫描上限2000条，接口total可能封顶；扩大范围或调整已支持的日期条件应明确告诉用户。

团队默认没有伙伴、职位、日期或积分门槛。partner_mode是可选的旧伙伴启发式，包含行业/竞品名称排除和技术场景评分；其中历史反馈仅代表当时信息。只在明确需要该模式时开启，并告知它包含名称排除；更精确需求用公司关键词或页面条件。

## 状态、身份和平台

`state/call-failed.json`位于同一个个人配置目录下，不随技能重新安装而改变。它包含待核进度和内部ID，应保留本地，不加入分享包。不要用另一个`--journal`重新发布未核实的任务。首次从旧个人CLI迁移时，先核对旧进度文件，不把待确认任务当作新任务执行。

CLI通过ego-browser标准输入传入脚本，不依赖zsh；Mac使用进程组和flock，Windows使用进程组、taskkill及msvcrt文件锁。Windows仅接受可直接执行的ego-browser.exe，不把.cmd/.bat交给shell执行。若安装后的官方CLI只有批处理入口，本包不能承诺可用，停止并交由维护者适配。Windows文件权限和落盘语义不同，不承诺POSIX的0600权限或目录fsync保证。

适配器固定为当前内部租户及公共库；`status`核对租户，成员模板读取为空时为“空库或访问未确认”，不能据此断言账号无权限。精确OB ID查询用页面搜索并核对详情；不能把OB ID直接当内部ID传给`detail/claim`。

Windows安装、实际ego-browser入口和CRM全流程尚未在Windows真机验证；本包的本机离线测试也不能替代其他同事的账号权限验证。
