"""Per-user preferences, independent of the installed skill and CRM state."""
import copy
import datetime as dt
import json
import os
from pathlib import Path


def user_dir():
    if os.name == 'nt':
        return Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData/Local')) / 'fxiaoke-lead-claim'
    return Path.home() / '.config/fxiaoke-lead-claim'


DEFAULTS = {
    'version': 1,
    'lead_date_before': None,
    'positions': [],
    'require_company': False,
    'prefer_nonzero_recent_points': False,
    'company_include_keywords': [],
    'company_exclude_keywords': [],
    'partner_mode': False,
    'exclude_historical_no_interest': False,
    'deduplicate_company': True,
    'watched_sales_lead_owners': [],
}


def load(path=None):
    target = Path(path).expanduser() if path else user_dir() / 'preferences.json'
    result = copy.deepcopy(DEFAULTS)
    if path is not None or target.exists():
        try:
            supplied = json.loads(target.read_text(encoding='utf-8'))
        except (OSError, ValueError) as exc:
            raise ValueError(f'偏好配置无法读取：{target}：{exc}') from exc
        if not isinstance(supplied, dict):
            raise ValueError('偏好配置必须为 JSON 对象')
        if set(supplied) - set(DEFAULTS):
            raise ValueError('存在未知配置项：' + ', '.join(sorted(set(supplied) - set(DEFAULTS))))
        result.update(supplied)
    validate(result)
    return result


def validate(config):
    if type(config['version']) is not int or config['version'] != 1:
        raise ValueError('不支持的配置版本')
    for key, default in DEFAULTS.items():
        value = config[key]
        if isinstance(default, bool) and type(value) is not bool:
            raise ValueError(f'{key} 必须为 true 或 false')
        if isinstance(default, list) and (not isinstance(value, list) or
                any(not isinstance(x, str) or not x.strip() for x in value)):
            raise ValueError(f'{key} 必须为非空字符串组成的数组，或空数组')
    day = config['lead_date_before']
    if day is not None:
        if not isinstance(day, str):
            raise ValueError('lead_date_before 必须为 YYYY-MM-DD 或 null')
        try:
            dt.datetime.strptime(day, '%Y-%m-%d')
        except ValueError as exc:
            raise ValueError('lead_date_before 必须为 YYYY-MM-DD 或 null') from exc


def initialize(path=None):
    target = Path(path).expanduser() if path else user_dir() / 'preferences.json'
    target.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as handle:
        json.dump(DEFAULTS, handle, ensure_ascii=False, indent=2)
        handle.write('\n')
    return target
