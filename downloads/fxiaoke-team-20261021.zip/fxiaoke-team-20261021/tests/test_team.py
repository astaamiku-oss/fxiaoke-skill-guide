import contextlib
import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE / 'fxiaoke-lead-claim/scripts'))
import fxiaoke_cli as fx
import preferences

spec = importlib.util.spec_from_file_location('team_installer', PACKAGE / 'install.py')
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)


def lead(identifier='a', company='某银行有限公司', **extra):
    return dict(id=identifier, company=company, pool=fx.POOL, owner=None,
                status='un_assigned', recent_points=None, position='DBA',
                **extra)


class TeamDefaults(unittest.TestCase):
    def setUp(self):
        self.old = fx.CONFIG
        fx.CONFIG = copy.deepcopy(preferences.DEFAULTS)

    def tearDown(self):
        fx.CONFIG = self.old

    def test_no_personal_date_or_position_constraints(self):
        query = json.loads(fx.query(None, 10)['search_query_info'])
        self.assertEqual([r['field_name'] for r in query['filters']], ['leads_pool_id'])
        self.assertEqual(fx.CONFIG['watched_sales_lead_owners'], [])
        self.assertEqual(len(fx.rank_candidates([lead()])), 1)

    def test_explicit_date_uses_verified_field_and_timezone(self):
        fx.CONFIG['positions'] = ['架构师']
        q = fx.query(fx.date_ms('2026-06-01'), 100, 200)
        self.assertEqual(q['params_of_default_template']['extend_attribute'], 'salesclueformember')
        filters = json.loads(q['search_query_info'])['filters']
        self.assertEqual(filters[-1]['field_values'], [1780243200000])
        self.assertEqual(filters[-1]['field_name'], 'field_8Hjq2__c')

    def test_recent_points_gate_is_opt_in_and_never_uses_total(self):
        fx.CONFIG['prefer_nonzero_recent_points'] = True
        self.assertFalse(fx.meets_preferences(lead(total_points=100)))
        row = lead()
        row['recent_points'] = '1'
        self.assertTrue(fx.meets_preferences(row))

    def test_no_interest_not_automatically_discarded(self):
        row = lead(profile_quality='沟通后无意向')
        self.assertTrue(fx.meets_preferences(row))
        fx.CONFIG['exclude_historical_no_interest'] = True
        self.assertFalse(fx.meets_preferences(row))

    def test_company_filters_apply_to_query_rows(self):
        fx.CONFIG['company_include_keywords'] = ['软件', '银行']
        fx.CONFIG['company_exclude_keywords'] = ['保险']
        self.assertTrue(fx.meets_preferences(lead()))
        self.assertFalse(fx.meets_preferences(lead(company='保险软件公司')))
        self.assertFalse(fx.meets_preferences(lead(company='医院')))

    def test_default_preserves_input_order_without_partner_scoring(self):
        rows = [lead('a'), lead('b', company='测试软件公司')]
        rows[1]['recent_points'] = 999
        rows[1]['latest_follow_up'] = '软件承包商，选型测试AI'
        result = fx.rank_candidates(rows)
        self.assertEqual([r['id'] for r in result], ['a', 'b'])
        self.assertTrue(all(r['priority_score'] is None for r in result))

    def test_partner_mode_is_opt_in(self):
        fx.CONFIG['partner_mode'] = True
        self.assertFalse(fx.meets_preferences(lead()))
        self.assertTrue(fx.meets_preferences(lead(company='测试软件公司')))

    def test_blank_companies_are_not_collapsed(self):
        result = fx.rank_candidates([lead('a', company=''), lead('b', company='')])
        self.assertEqual(len(result), 2)

    def test_customer_owner_always_excludes_even_with_empty_watchlist(self):
        data = dict(id='current', sales_leads=dict(records=[], complete=True),
                    customers=dict(records=[dict(has_owner=True, owner_names=['其他同事(已停用)'])], complete=True))
        self.assertEqual(fx.decorate_duplicates(data)['status'], 'customer_has_owner')

    def test_current_record_not_a_watch_hit(self):
        fx.CONFIG['watched_sales_lead_owners'] = ['示例负责人']
        data = dict(id='current', sales_leads=dict(records=[dict(id='current', has_owner=True,
                    owner_names=['示例负责人'])], complete=True), customers=dict(records=[], complete=True))
        self.assertEqual(fx.decorate_duplicates(data)['watch_hits'], [])


class ConfigurationAndCommands(unittest.TestCase):
    def invoke(self, argv, response=None):
        out = io.StringIO()
        with tempfile.TemporaryDirectory() as directory, patch.object(preferences, 'user_dir', return_value=Path(directory)), \
             patch.object(fx, 'bridge', return_value=response or {}) as browser, \
             patch.object(fx, 'close_space') as close, contextlib.redirect_stdout(out):
            rc = fx.main(['--json', '--keep-open', *argv])
        return rc, json.loads(out.getvalue()), browser, close

    def test_config_show_is_entirely_offline(self):
        rc, data, browser, close = self.invoke(['config', 'show'])
        self.assertEqual(rc, 0)
        self.assertFalse(data['crm_contacted'])
        browser.assert_not_called()
        close.assert_not_called()

    def test_initialize_refuses_to_overwrite_user_preferences(self):
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory) / 'personal.json'
            preferences.initialize(p)
            original = p.read_bytes()
            with self.assertRaises(FileExistsError):
                preferences.initialize(p)
            self.assertEqual(p.read_bytes(), original)

    def test_invalid_or_unknown_config_never_silently_falls_back(self):
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory) / 'preferences.json'
            for value in [[], {'company_includes': ['软件']}, {'prefer_nonzero_recent_points': 'false'},
                          {'version': True}, {'positions': '架构师'}, {'lead_date_before': 12}]:
                p.write_text(json.dumps(value), encoding='utf-8')
                with self.assertRaises(ValueError):
                    preferences.load(p)
            with self.assertRaises(ValueError):
                preferences.load(Path(directory) / 'missing.json')

    def test_status_does_not_use_personal_cutoff(self):
        rc, data, browser, close = self.invoke(['status'])
        self.assertEqual(rc, 0)
        q = json.loads(browser.call_args.args[1]['query']['search_query_info'])
        self.assertFalse(any(f['field_name'] == 'field_8Hjq2__c' for f in q['filters']))

    def test_search_enforces_recent_points_in_local_scan(self):
        rc, data, browser, close = self.invoke(['search', '--recent-points', 'nonzero'],
                                              {'leads': [lead()], 'scanned': 1})
        self.assertEqual(rc, 0)
        self.assertEqual(data['leads'], [])
        self.assertEqual(data['scanned'], 1)

    def test_claim_deduplicates_only_authorized_ids(self):
        identifier = '000000000000000000000001'
        rc, data, browser, close = self.invoke(['claim', identifier, identifier, '--execute'],
                                              {'results': [], 'stopped': False})
        self.assertEqual(rc, 0)
        self.assertEqual(browser.call_args.args[1]['ids'], [identifier])
        self.assertEqual(browser.call_args.args[1]['watched'], [])
        self.assertFalse(data['read_only'])

    def test_claim_without_execute_rejected(self):
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            fx.build_parser().parse_args(['claim', '000000000000000000000001'])

    def test_transport_failure_stops_without_cleanup_or_retry(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(preferences, 'user_dir', return_value=Path(directory)), \
             patch.object(fx, 'bridge', side_effect=fx.CliError('用户正在控制')) as browser, \
             patch.object(fx, 'close_space') as close, contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(fx.main(['status']), 1)
        self.assertEqual(browser.call_count, 1)
        close.assert_not_called()

    @unittest.skipIf(os.name == 'nt', 'POSIX executable fixture')
    def test_process_stdin_preserves_text_without_shell_interpolation(self):
        with tempfile.TemporaryDirectory() as directory:
            executable = Path(directory) / 'ego-test'
            executable.write_text('#!' + sys.executable + '\nimport sys,json\n'
                                  'print("FX_RESULT:"+json.dumps({"ok":True,"data":{"script":sys.stdin.read(),"args":sys.argv[1:]}}))\n')
            executable.chmod(0o700)
            source = 'const x = "$(echo unexpected)`echo unexpected`中文";'
            with patch.object(fx, 'ego_binary', return_value=str(executable)):
                result = fx.ego_run(source, timeout=5)
            self.assertEqual(result, {'script': source, 'args': ['nodejs']})


class Installer(unittest.TestCase):
    def test_one_real_copy_and_only_chosen_agent(self):
        with tempfile.TemporaryDirectory() as directory:
            home = Path(directory)
            center, target = installer.install(PACKAGE / 'fxiaoke-lead-claim', home, 'codex')
            self.assertTrue(target.is_symlink())
            self.assertEqual(target.resolve(), center.resolve())
            self.assertFalse((home / '.qoder').exists())
            self.assertFalse((home / '.config').exists())
            self.assertEqual(installer.install(PACKAGE / 'fxiaoke-lead-claim', home, 'codex'), (center, target))

    def test_existing_skill_not_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            home = Path(directory)
            target = home / '.codex/skills/fxiaoke-lead-claim'
            target.mkdir(parents=True)
            (target / 'personal.txt').write_text('keep me')
            with self.assertRaises(ValueError):
                installer.install(PACKAGE / 'fxiaoke-lead-claim', home, 'codex')
            self.assertEqual((target / 'personal.txt').read_text(), 'keep me')
            self.assertFalse((home / '.agents').exists())

    def test_different_center_version_not_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            home = Path(directory)
            center = home / '.agents/skills/fxiaoke-lead-claim'
            center.mkdir(parents=True)
            (center / 'old.txt').write_text('old')
            with self.assertRaises(ValueError):
                installer.install(PACKAGE / 'fxiaoke-lead-claim', home, 'codex')
            self.assertEqual((center / 'old.txt').read_text(), 'old')


if __name__ == '__main__':
    unittest.main()
