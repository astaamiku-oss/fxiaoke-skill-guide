"""Install one internal skill; never overwrite existing skills or user preferences."""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys

NAME = 'fxiaoke-lead-claim'
AGENTS = {'codex': '.codex/skills', 'qoder': '.qoder/skills',
          'pi': '.pi/agent/skills', 'claude': '.claude/skills'}


def files(path):
    return {str(p.relative_to(path)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in path.rglob('*') if p.is_file() and '__pycache__' not in p.parts
            and p.suffix != '.pyc'}


def install(source, home, agent, windows=None):
    windows = os.name == 'nt' if windows is None else windows
    center = home / '.agents/skills' / NAME
    target = home / AGENTS[agent] / NAME
    if target.exists() or target.is_symlink():
        if target.resolve() != center.resolve():
            raise ValueError(f'发现已有技能，未覆盖：{target}。请让 AI 比较旧版后再安排升级。')
    if center.exists():
        if files(center) != files(source):
            raise ValueError(f'已有不同版本，未覆盖：{center}。请先备份和比较，保留本人的偏好与待确认进度。')
    else:
        center.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(source, center, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    if target.exists() or target.is_symlink():
        return center, target
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        target.symlink_to(center, target_is_directory=True)
    except OSError:
        if not windows:
            raise
        # Junctions work without Developer Mode. Reject cmd metacharacters in paths.
        if any(c in str(target) + str(center) for c in '"&|<>^%!\r\n'):
            raise ValueError('路径包含命令特殊字符，未创建Windows目录联接；请由IT协助。')
        result = subprocess.run(['cmd.exe', '/d', '/c', f'mklink /J "{target}" "{center}"'],
                                capture_output=True, check=False)
        if result.returncode != 0:
            raise ValueError(f'无法创建目录联接；真实文件已保留在 {center}，请让AI或IT协助接入。')
    return center, target


def main():
    parser = argparse.ArgumentParser(description='只安装到所选AI；不会登录或操作CRM，也不会覆盖已有技能。')
    parser.add_argument('--agent', required=True, choices=AGENTS)
    args = parser.parse_args()
    try:
        center, target = install(Path(__file__).resolve().parent / NAME, Path.home(), args.agent)
        print(f'技能文件：{center}\nAI入口：{target}\n请重新打开AI会话，再说：检查纷享销客环境，先不要领取。')
        return 0
    except (OSError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
