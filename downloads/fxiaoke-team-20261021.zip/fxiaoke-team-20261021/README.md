# 纷享销客电销助手：内部团队试用包

供OceanBase内部电销团队使用。普通同事先看`开始使用.txt`，把包交给自己的AI即可。AI需要有本地命令和文件操作能力；普通网页聊天窗口不能直接运行此包。每位同事使用自己的纷享销客账号和公共库权限。

这是独立分享版，没有覆盖制作者现用技能。未公开发布，未附带对外开源许可；后续公开版需要另行抽离租户适配并决定许可。包内仅包含代码、说明和合成测试，不带客户结果、个人名单、登录态或任务进度。

## 安装

解压后，让AI先读技能说明，再确认当前使用的AI并只安装一个入口。脚本将真实文件集中放在`~/.agents/skills/fxiaoke-lead-claim`，为所选AI创建符号链接；Windows无法建符号链接时尝试目录联接。已有不同版本或其他真实目录时拒绝覆盖，先比较和备份；不会动本人的偏好与进度。脚本不维护别的软件的路由清单；已有skill_router管理时由AI先读取其status，再按既有管理方式接入，不混用安装器覆盖。

Mac（在本包目录）：
```bash
python3 install.py --agent codex
```

Windows PowerShell（在本包目录，有Python启动器时）：
```powershell
py -3 install.py --agent codex
```

也可选`qoder`、`pi`、`claude`。只安装本人选定的AI；AI应在命令不可用时检查现有Python，不要求新人自己调试。建议Python 3.10+；实际测试版本记录在`VALIDATION.txt`。

从[ego lite官网](https://lite.ego.app/)下载对应系统版本，由本人完成引导、登录。首次业务调用用`status`检查租户和公共库；技能安装脚本本身不连接CRM。Windows实际ego-browser入口须现场验证，当前包仅支持可直接执行的`.exe`入口；只有`.cmd/.bat`时停止并反馈维护者。Mac/Windows版本尚未分别完成新用户真机验收。

## 给维护者

通用业务规则写在`SKILL.md`，具体命令与个人配置在`references/runtime.md`，页面条件和接管流程在`references/browser.md`。租户字段与公共库仍固定在适配器中，不能拿到其他租户直接用。

本次移除团队默认中的固定日期、职位、伙伴名称门槛、积分门槛、历史无意向排除与个人八人名单；保留查重、单次领取、回读验证及未接通任务防重复。伙伴启发式评分作为可选模式保留，不默认生效。页面复杂筛选仍为AI动态操作指引，未对每一个控件和组合做端到端验证。

偏好不在安装目录中；日常记录状态文件也采用稳定的个人目录。原个人CLI迁移时须先查看旧进度文件，尤其不得通过新目录绕过未确认的提交。通用历史动态读取、任意字段修改、删除和退回均未实现。

离线检查（不会连接浏览器）：
```bash
python3 -m unittest discover -s tests -p 'test_*.py' -v
node tests/test_claim.cjs
node tests/test_failed_call.cjs
```

在Windows使用本机Python命令替换`python3`。测试会导入本包运行时，全部CRM和浏览器调用使用模拟数据；Node仅用于维护者离线测试，业务运行依赖ego自带Node运行时。请不要把`.state`、用户preferences、客户导出或凭证加入后续分享包。
